import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

export type MoveNode = {
  id: string;
  parentId: string | null;
  childrenIds: string[];

  side: 'sente' | 'gote' | null;
  kind: 'root' | 'move' | 'drop';
  label: string;
  sfenAfter: string;

  from?: string;
  to?: string;
  role?: string;
  promotion?: boolean;
};

export type VariationOption = {
  nodeId: string;
  label: string;
  side: 'sente' | 'gote';
};

export type VariationMove = {
  nodeId: string;
  label: string;
  side: 'sente' | 'gote';
  ply: number;
};

export type VariationLine = {
  startNodeId: string;
  moves: VariationMove[];
};

export type MoveHistoryEntry = {
  nodeId: string;
  ply: number;
  side: 'sente' | 'gote';
  kind: 'move' | 'drop';
  label: string;
  sfenAfter: string;

  from?: string;
  to: string;
  role?: string;
  promotion?: boolean;

  variations: VariationLine[];
};

type MoveHistoryRow = {
  moveNumber: number;
  sente?: MoveHistoryEntry;
  gote?: MoveHistoryEntry;
};

@Component({
  selector: 'app-move-history',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './move-history.html',
  styleUrl: './move-history.css',
})
export class MoveHistoryComponent {
  @Input() history: MoveHistoryEntry[] = [];
  @Input() currentPly = 0;

  @Output() selectPly = new EventEmitter<number>();

  @Output() selectNode = new EventEmitter<string>();

  onSelectNode(nodeId: string): void {
    this.selectNode.emit(nodeId);
  }

  get rows(): MoveHistoryRow[] {
    const rows: MoveHistoryRow[] = [];

    for (const entry of this.history) {
      const rowIndex = Math.floor((entry.ply - 1) / 2);

      if (!rows[rowIndex]) {
        rows[rowIndex] = {
          moveNumber: rowIndex + 1,
        };
      }

      if (entry.side === 'sente') {
        rows[rowIndex].sente = entry;
      } else {
        rows[rowIndex].gote = entry;
      }
    }

    return rows;
  }

  onSelectPly(ply: number): void {
    this.selectPly.emit(ply);
  }

  trackByMoveNumber(_: number, row: MoveHistoryRow): number {
    return row.moveNumber;
  }
}
